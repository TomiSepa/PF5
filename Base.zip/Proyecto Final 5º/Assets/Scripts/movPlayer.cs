﻿using UnityEngine;
using System.Collections;

public class movPlayer : MonoBehaviour {

    public float movSpeed;

    public Rigidbody rb;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	    var hMov = Input.GetAxis("Horizontal") * movSpeed;
        var vMov = Input.GetAxis("Vertical") * movSpeed;

        Vector3 vel = new Vector3(hMov, 0, vMov);
        vel = Camera.main.transform.TransformDirection(vel);
        rb.velocity = vel.normalized * movSpeed;

        transform.LookAt(transform.position + rb.velocity);
	}
}
